﻿
Partial Class Site_Mobile
    Inherits System.Web.UI.MasterPage
End Class

